package Des.Server;

public class DESInterface {
    public static void main(String[] args) {
        new GUI();
    }
}